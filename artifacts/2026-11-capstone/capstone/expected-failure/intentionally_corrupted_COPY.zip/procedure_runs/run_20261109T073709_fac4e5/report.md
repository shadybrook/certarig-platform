# Jacket thermal soak

- Procedure `thermal_soak` hash `daf032eea8b5192a3df9098b30d3daba76d68ea0b414d35acad8af9aef452d18`
- Run `run_20261109T073709_fac4e5` · **passed** · all steps and checks passed
- Rig `certarig-thermal-sim` (simulator) config `3f689bdd7a816ed9`
- Contract `fe7fd33dfaf965e8`
- Hardware `SimulatedRig@Chintans-MacBook-Air.local config=3f689bdd7a81`
- CertaRig 0.4.0

## Deterministic results

| Step | Type | Status | Detail |
| --- | --- | --- | --- |
| in_band | expect | passed |  |
| soak | wait | passed |  |
| still_in_band | expect | passed |  |
| end_safe | command | passed |  |

## Checks

- PASS: {'step_passed': 'still_in_band'}
- PASS: {'signal': 'temperature', 'peak_below': 85.0}

## Kernel events

- `estop_closed_reset_required`
- `csv_recording_started`
- `operator_safe`

## Recording

`20261109T073709097787Z_thermal_soak.csv` · 77 samples · sha256 `eb4acc04878b6911967e42a48e5b5955825296b94dbd8c8253f51f5146eda59a`

## Bench briefing

_No bench briefing was saved._

## Agent narrative

The following text, if present, is the agent's explanation. It is **not** a measurement.

_No agent narrative was attached._

## Recovery

If the soak aborted, force safe, inspect the temperature tag, then acknowledge any unclean boot before retrying.

## Soak notes

This skill proves a generic temperature concept. Hardware `SimulatedRig@Chintans-MacBook-Air.local config=3f689bdd7a81`.
The numbers in the tables above came from the kernel, not from an agent.

## Reproducible raw sample analysis

```json
{
  "channels": {
    "jacket_c": {
      "maximum": 47.66502,
      "minimum": 47.41051,
      "observations": 77,
      "unit": "degC"
    }
  },
  "command_rows": 2,
  "kind": "raw_sample_summary",
  "output_state_source": "command_derived_not_electrical_feedback",
  "rows": 77,
  "sample_rows": 75,
  "unsafe_command_rows": 0
}
```
