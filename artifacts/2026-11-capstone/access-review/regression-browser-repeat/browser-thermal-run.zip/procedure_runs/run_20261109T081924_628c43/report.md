# Jacket thermal soak

- Procedure `thermal_soak` hash `daf032eea8b5192a3df9098b30d3daba76d68ea0b414d35acad8af9aef452d18`
- Run `run_20261109T081924_628c43` · **passed** · all steps and checks passed
- Rig `certarig-thermal-sim` (simulator) config `c384a44696aed216`
- Contract `3b2790fdcc815f3f`
- Hardware `SimulatedRig@Chintans-MacBook-Air.local config=c384a44696ae`
- CertaRig 0.4.0

## Deterministic results

| Step | Type | Status | Detail |
| --- | --- | --- | --- |
| in_band | expect | passed |  |
| soak | wait | passed |  |
| still_in_band | expect | passed |  |
| end_safe | command | passed |  |

## Checks

- PASS: {'step_passed': 'still_in_band'}
- PASS: {'signal': 'temperature', 'peak_below': 85.0}

## Kernel events

- `operator_safe`
- `csv_recording_started`
- `operator_safe`

## Recording

`20261109T081924217871Z_thermal_soak.csv` · 77 samples · sha256 `89bbd4597e8302bf5b30d29f35c3a2842339f3bdfa83479a90ce57dcfdb0d7da`

## Bench briefing

- **p1_role**: P1 pressure emulator
- **p2_role**: P2 flow emulator
- **estop**: GPIO24 mushroom
- **relay**: GPIO23 permit
- **diagram_notes**: wave-1 as-built
- updated_at: `2026-11-09T08:19:15.914022+00:00`

## Agent narrative

The following text, if present, is the agent's explanation. It is **not** a measurement.

_No agent narrative was attached._

## Recovery

If the soak aborted, force safe, inspect the temperature tag, then acknowledge any unclean boot before retrying.

## Soak notes

This skill proves a generic temperature concept. Hardware `SimulatedRig@Chintans-MacBook-Air.local config=c384a44696ae`.
The numbers in the tables above came from the kernel, not from an agent.

## Reproducible raw sample analysis

```json
{
  "channels": {
    "reactor_temperature": {
      "maximum": 47.62445,
      "minimum": 47.38151,
      "observations": 77,
      "unit": "degC"
    }
  },
  "command_rows": 2,
  "kind": "raw_sample_summary",
  "output_state_source": "command_derived_not_electrical_feedback",
  "rows": 77,
  "sample_rows": 75,
  "unsafe_command_rows": 0
}
```
