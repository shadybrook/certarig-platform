# Jacket thermal soak

- Procedure `thermal_soak` hash `daf032eea8b5192a3df9098b30d3daba76d68ea0b414d35acad8af9aef452d18`
- Run `run_20261109T091655_263775` · **passed** · all steps and checks passed
- Rig `certarig-thermal-sim` (simulator) config `87993fe5875d31e9`
- Contract `8030949dc26d97d1`
- Hardware `SimulatedRig@Chintans-MacBook-Air.local config=87993fe5875d`
- CertaRig 0.4.0

## Deterministic results

| Step | Type | Status | Detail |
| --- | --- | --- | --- |
| in_band | expect | passed |  |
| soak | wait | passed |  |
| still_in_band | expect | passed |  |
| end_safe | command | passed |  |

## Checks

- PASS: {'step_passed': 'still_in_band'}
- PASS: {'signal': 'temperature', 'peak_below': 85.0}

## Kernel events

- `operator_safe`
- `csv_recording_started`
- `operator_safe`

## Recording

`20261109T091655463580Z_thermal_soak.csv` · 77 samples · sha256 `5d90e002d31b6f9262e2b5d58512bb324944905b01d42c2549160e0f875b89b5`

## Bench briefing

- **p1_role**: P1 pressure emulator
- **p2_role**: P2 flow emulator
- **estop**: GPIO24 mushroom
- **relay**: GPIO23 permit
- **diagram_notes**: wave-1 as-built
- updated_at: `2026-11-09T09:16:47.610764+00:00`

## Agent narrative

The following text, if present, is the agent's explanation. It is **not** a measurement.

_No agent narrative was attached._

## Recovery

If the soak aborted, force safe, inspect the temperature tag, then acknowledge any unclean boot before retrying.

## Soak notes

This skill proves a generic temperature concept. Hardware `SimulatedRig@Chintans-MacBook-Air.local config=87993fe5875d`.
The numbers in the tables above came from the kernel, not from an agent.

## Reproducible raw sample analysis

```json
{
  "channels": {
    "reactor_temperature": {
      "maximum": 45.12445,
      "minimum": 44.88151,
      "observations": 77,
      "unit": "degC"
    }
  },
  "command_rows": 2,
  "feedback_observations": 0,
  "feedback_transition_intervals_s": [],
  "kind": "raw_sample_summary",
  "output_state_source": "command_derived_not_electrical_feedback",
  "rows": 77,
  "sample_rows": 75,
  "unsafe_command_rows": 0
}
```
