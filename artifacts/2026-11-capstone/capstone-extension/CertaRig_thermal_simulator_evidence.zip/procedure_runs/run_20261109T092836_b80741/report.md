# Jacket thermal soak

- Procedure `thermal_soak` hash `daf032eea8b5192a3df9098b30d3daba76d68ea0b414d35acad8af9aef452d18`
- Run `run_20261109T092836_b80741` · **passed** · all steps and checks passed
- Rig `capstone-interview-thermal-demo` (simulator) config `c8ba9834595bf42c`
- Contract `8f6b119f19a9f891`
- Hardware `SimulatedRig@Chintans-MacBook-Air.local config=c8ba9834595b`
- CertaRig 0.4.0

## Deterministic results

| Step | Type | Status | Detail |
| --- | --- | --- | --- |
| in_band | expect | passed |  |
| soak | wait | passed |  |
| still_in_band | expect | passed |  |
| end_safe | command | passed |  |

## Checks

- PASS: {'step_passed': 'still_in_band'}
- PASS: {'signal': 'temperature', 'peak_below': 85.0}

## Kernel events

- `csv_recording_stopped`
- `csv_recording_started`
- `operator_safe`

## Recording

`20261109T092836686905Z_thermal_soak.csv` · 77 samples · sha256 `bc3aa179afe709663703d90c12351596e2902c9a74fb1465d2c7a59da115f607`

## Bench briefing

_No bench briefing was saved._

## Agent narrative

The following text, if present, is the agent's explanation. It is **not** a measurement.

_No agent narrative was attached._

## Recovery

If the soak aborted, force safe, inspect the temperature tag, then acknowledge any unclean boot before retrying.

## Soak notes

This skill proves a generic temperature concept. Hardware `SimulatedRig@Chintans-MacBook-Air.local config=c8ba9834595b`.
The numbers in the tables above came from the kernel, not from an agent.

## Reproducible raw sample analysis

```json
{
  "channels": {
    "jacket_c": {
      "maximum": 45.12445,
      "minimum": 44.87777,
      "observations": 77,
      "unit": "degC"
    }
  },
  "command_rows": 2,
  "feedback_observations": 0,
  "feedback_transition_intervals_s": [],
  "kind": "raw_sample_summary",
  "output_state_source": "command_derived_not_electrical_feedback",
  "rows": 77,
  "sample_rows": 75,
  "unsafe_command_rows": 0
}
```
