# Safe power-down of the edge node

- Procedure `safe_powerdown` hash `46a6894f08e37e771fae737c1259d3655de7c40f0a64fd25b1801649145274f9`
- Run `run_20260913T070408_8d09f8` · **passed** · all steps and checks passed
- Rig `certarig-wave1-dry-bench` (raspberry_pi) config `ed2f30f44470baac`
- Contract `9e144a0f814cb072`
- Hardware `RaspberryPiHardware@certarig-pi config=e9922ec2e77b`
- CertaRig 0.4.0

## Deterministic results

| Step | Type | Status | Detail |
| --- | --- | --- | --- |
| force_safe | command | passed |  |
| hold_safe | expect | passed |  |
| not_recording | expect | passed |  |
| confirm_bench | await_operator | passed | Confirm the green indicator is dark, the E-stop is released or pressed as you prefer for storage, and that you are ready to remove the external 5 V supply after shutdown.
 |
| final_safe | command | passed |  |

## Checks

- PASS: {'event_not_observed': 'permit_accepted'}
- PASS: {'step_passed': 'confirm_bench'}

## Kernel events

- `estop_closed_reset_required`
- `operator_safe`

## Recording

_No CSV recording._

## Bench briefing

- **p1_role**: Pressure emulator P1, ADS1115 A0
- **p2_role**: Flow emulator P2, ADS1115 A1
- **estop**: GPIO24 mushroom head
- **relay**: GPIO23 permit / indicator
- **diagram_notes**: Wave-1 dry bench sidecar lab 2026-09-12. Phase 3 files not used.
- updated_at: `2026-09-12T16:23:44.654891+00:00`

## Agent narrative

The following text, if present, is the agent's explanation. It is **not** a measurement.

_No agent narrative was attached._

## Recovery

If the node cannot reach a safe state, remove the external 5 V relay supply first, then the Pi PWR IN. Record what was observed.
